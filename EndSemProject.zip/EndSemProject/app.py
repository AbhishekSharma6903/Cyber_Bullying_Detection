from flask import Flask, request, render_template

import re
import nltk
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import TfidfVectorizer
import re, string

import pickle

with open('models/model.pickle', 'rb') as fd:
    rfcmodel = pickle.load(fd)
    
with open('models/tokenizer.pickle', 'rb') as fd:
    tfIdfVectorizer = pickle.load(fd, encoding='utf=8')

nltk.download('stopwords')
nltk.download('punkt')

def check_for_cyberbullying(input_text):

    porter_stemmer = PorterStemmer()
    regex = re.compile('[%s]' % re.escape(string.punctuation))
    # tfIdfVectorizer = TfidfVectorizer(use_idf=True, sublinear_tf=True)

    # Assume you have a new data point stored in a variable `new_data`
    new_data = input_text
    stop = stopwords.words('english')

    # Preprocess the input data to match the format used for training
    new_data = ' '.join([word for word in new_data.split() if word not in (stop)])
    new_data = regex.sub('',new_data)
    nltk_tokens = nltk.word_tokenize(new_data)
    final = ''
    for w in nltk_tokens:
        final = final + ' ' + porter_stemmer.stem(w)
    new_data = ''.join([i for i in final if not i.isdigit()])

    # Convert the preprocessed input data to a format compatible with the trained model
    new_data_vectorized = tfIdfVectorizer.transform([new_data])

    # Make a prediction using the trained model
    prediction = rfcmodel.predict(new_data_vectorized.toarray())[0]

    return prediction


app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():

    if request.method == "POST":
        
        data = request.form.to_dict()
        message = data['message']

        if check_for_cyberbullying(message):

            return render_template('results.html', message=message, result="cyber bullying")
        
        else: return render_template('results.html', message=message, result="cyber safe")

    else:

        return render_template("home.html")

app.run(host="0.0.0.0", port="1234")