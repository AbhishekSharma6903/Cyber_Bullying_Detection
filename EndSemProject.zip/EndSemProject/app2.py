from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/')
def index():

    return "<html><h1>Hello There Friend</h1></html>"

@app.route('/request', methods=['GET', 'POST'])
def use_requests():

    if request.method == 'POST':

        return "this was posted"
    
    else: return render_template('home.html')

@app.route('/api/<int:holder>')
def api(holder):

    return f"this is {holder}"

app.run(debug=True, port=5555)